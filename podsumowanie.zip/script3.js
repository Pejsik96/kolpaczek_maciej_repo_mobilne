$(document).ready(function() {
    var rot=0;
    $("#uparr").click(function() {
      $("div").animate({'top': '-=20'},"slow",);
    });
    
    $("#downarr").click(function() {
      $("div").animate({'top': '+=20'},"slow",);
    });
    
    $("#leftarr").click(function() {
      $("div").animate({'left': '-=20'},"slow",);
    });
    
    $("#rightarr").click(function() {
      $("div").animate({'left': '+=20'},"slow",);
    });
    $("#rotatearr").click(function() {
      rot += 90
      $("div").css({'transform': 'rotate('+rot+'deg)'});
      console.log("cdfff")
    });
  });