$(document).ready(function(){
    $(".circle").hide();
    $(".1").click(function() {
        if($('#white').is(':checked')){
            $(".circle").hide();
            $(".circle").css({
                "background-color": "white"
            });
            $(".circle").toggle();
         }
         else if($('#black').is(':checked')){
            $(".circle").hide();
            $(".circle").css({
                "background-color": "black"
            });
            $(".circle").toggle();
         }
         else if($('#green').is(':checked')){
            $(".circle").hide();
            $(".circle").css({
                "background-color": "green"
            });
            $(".circle").toggle();
         }
         else if($('#blue').is(':checked')){
            $(".circle").hide();
            $(".circle").css({
                "background-color": "blue"
            });
            $(".circle").toggle();
         }
         else if($('#red').is(':checked')){
            $(".circle").hide();
            $(".circle").css({
                "background-color": "red"
            });
            $(".circle").toggle();
         }
    });
});