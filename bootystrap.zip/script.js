$(document).ready(function(){
    $("#Stalin").click(function() {
        $('#foto').attr("src","stalin.jpg");
    });
    $("#Lenin").click(function() {
        $('#foto').attr("src","lenin.jpg");
    });
    $("#Jaruzelski").click(function() {
        $('#foto').attr("src","karuzelski.jpg");
    });
    $("#Marks").click(function() {
        $('#foto').attr("src","marks.jpg");
    });
});