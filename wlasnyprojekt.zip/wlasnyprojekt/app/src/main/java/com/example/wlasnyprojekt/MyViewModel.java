package com.example.wlasnyprojekt;

import androidx.lifecycle.ViewModel;

public class MyViewModel extends ViewModel {
    int liczba =0;
    int upgrade=1;
    void addNumber(){
        liczba+=upgrade;
    }
    void addUpgrade(){ upgrade++; }
}
